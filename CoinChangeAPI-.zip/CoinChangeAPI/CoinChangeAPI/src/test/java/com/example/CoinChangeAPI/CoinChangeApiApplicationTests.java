package com.example.CoinChangeAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoinChangeApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
