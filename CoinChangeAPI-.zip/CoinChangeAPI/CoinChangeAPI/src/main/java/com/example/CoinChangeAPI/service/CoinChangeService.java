package com.example.CoinChangeAPI.service;

import com.example.CoinChangeAPI.models.MachineObj;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.Map;

@Service
public class CoinChangeService {
    private MachineObj vendingMachine;

    public CoinChangeService() {
        this.vendingMachine = new MachineObj();
    }
    public void initCoins(int one, int two, int five, int ten, int twenty, int fifty,
                          int pound, int twoPound) {
        Map<Integer, Integer> coins = new TreeMap<>(Collections.reverseOrder());
        coins.put(1, one);
        coins.put(2, two);
        coins.put(5, five);
        coins.put(10, ten);
        coins.put(20, twenty);
        coins.put(50, fifty);
        coins.put(100, pound);
        coins.put(200, twoPound);
        vendingMachine.setCoins(coins);
    }

    public void insrtCoin(int coin) {
        vendingMachine.insertCoin(coin);
    }

    public Map<Integer, Integer> getCoins() {
        return vendingMachine.getCoins();
    }

    public ArrayList<Integer> refund(int refundAmount) {
        Map<Integer, Integer> coins = vendingMachine.getCoins();
        ArrayList<Integer> refundCoins = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : coins.entrySet()) {
            int denomination = entry.getKey();
            int quantity = entry.getValue();
            if (quantity > 0 && denomination <= refundAmount) {
                int numCoins = Math.min(quantity, refundAmount / denomination);
                refundCoins.addAll(Collections.nCopies(numCoins, denomination));
                refundAmount -= numCoins * denomination;
                coins.put(denomination, (coins.get(denomination)) - numCoins);
            }
        }
        vendingMachine.setCoins(coins);
        if (refundAmount > 0) {
            System.out.println("Not Enough Change!");
        }
        return refundCoins;
    }



}
