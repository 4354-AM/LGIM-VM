package com.example.CoinChangeAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoinChangeApiApplication {
	public static void main(String[] args) {
		SpringApplication.run(CoinChangeApiApplication.class, args);
	}

}
