package com.example.CoinChangeAPI.models;


import java.util.Collections;
import java.util.Map;
import java.util.Map;
import java.util.TreeMap;

public class MachineObj {
    private Map<Integer, Integer> coins;

    public MachineObj() {
        coins = new TreeMap<>(Collections.reverseOrder());
        coins.put(1,0);
        coins.put(2,0);
        coins.put(5,0);
        coins.put(10,0);
        coins.put(20,0);
        coins.put(50,0);
        coins.put(100,0);
        coins.put(200,0);
    }

    public Map<Integer, Integer> getCoins(){
        return coins;
    }

    public void setCoins(Map<Integer, Integer> coins){
        this.coins = coins;
    }

    public void insertCoin(Integer denomination){
        if(coins.containsKey(denomination)){
            coins.put(denomination, coins.get(denomination)+1);
        }
        else {
            System.out.println("Invalid denomination");
        }
    }

}
