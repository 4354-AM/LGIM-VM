package com.example.CoinChangeAPI.controller;

import com.example.CoinChangeAPI.service.CoinChangeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Map;

@RestController
public class Controller {

    private final CoinChangeService coinService;

    @Autowired
    public Controller(CoinChangeService coinService) {
        this.coinService = coinService;
    }

    @PostMapping("/init-coins")
    public void initCoins(@RequestParam int one, @RequestParam int two, @RequestParam int five, @RequestParam int ten,
                          @RequestParam int twenty, @RequestParam int fifty, @RequestParam int pound, @RequestParam int twoPound) {
        coinService.initCoins(one, two, five, ten, twenty, fifty, pound, twoPound);
    }

    @PostMapping("/insert-coin")
    public void insrtCoins(@RequestParam int coin) {
        coinService.insrtCoin(coin);
    }

    @RequestMapping("/current-coins")
    public Map<Integer, Integer> currentCoins() {
        return coinService.getCoins();
    }

    @PostMapping("/refund")
    public ArrayList<Integer> refund(@RequestParam int refundAmount) {
        return coinService.refund(refundAmount);
    }
}
